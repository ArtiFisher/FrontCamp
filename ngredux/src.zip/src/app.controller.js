class AppController {
  constructor(){
    this.text = 'Hello';
  }
}

export default AppController;
