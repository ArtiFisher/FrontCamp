class PostsController {
  constructor(){
    this.text = 'text from posts ctrl';
    this.list = [{
      text: '111'
    },
    {
      text: '222'
    }];
  }

  selectPost(post){
    this.post = post;
  }
}

export default PostsController;
