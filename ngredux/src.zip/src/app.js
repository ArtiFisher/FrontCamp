import angular from 'angular';
import AppController from './app.controller.js';
import PostsComponent from './posts/posts.component.js';
import PostDetail from './post-detail/post-detail.component.js';

angular.module('app', [])
  .controller('appController', AppController)
  .component('posts', PostsComponent.createInstance())
  .component('postDetail', PostDetail.createInstance())
  // .directive('postsdir', () => PostsComponent.createInstance());
